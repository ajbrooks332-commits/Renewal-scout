# Renewal Scout — Replit setup guide

Renewal Scout is a private household-renewal dashboard for broadband, energy, insurance, cards, loans and similar services. It records renewal dates, runs current web research, builds a structured comparison and emails you when a report is ready.

It deliberately stops before submitting forms, applying for credit, cancelling a service, accepting a contract or making a payment. Personalised quotes still require you to verify declarations and complete the provider's final steps.

## What is included

- Password-protected FastAPI dashboard
- Household-service and renewal-date tracker
- Daily due-date scheduler (07:30 Europe/London by default)
- OpenAI Agents SDK researcher with web search and typed reports
- Up to three comparable options with clickable source URLs
- Missing-information, comparison and application checklists
- Optional email alerts
- PostgreSQL support for Replit Database, with SQLite for local testing
- CSRF protection, session cookies and a research audit trail
- No transaction, cancellation, application or payment capability

## 1. Create the Replit app

1. Download and unzip this project.
2. In Replit, create a new **Python** app.
3. Upload the contents of the `renewal-scout` folder so `requirements.txt`, `.replit`, `run_due_check.py` and the `app` folder are at the project root.
4. Open Replit's Shell and run:

   ```bash
   pip install -r requirements.txt
   ```

The supplied `.replit` file starts one Uvicorn worker on port 8080. One worker matters because the built-in scheduler must not be duplicated.

## 2. Add a Replit SQL Database

In the Replit workspace, add its SQL Database tool and create a database. Replit supplies `DATABASE_URL` automatically. The app also works with local SQLite when that variable is absent, but PostgreSQL is the durable choice for a published app.

No manual tables are needed; the app creates them on startup.

## 3. Add Secrets

Open **Tools → Secrets** and add these required values:

| Secret | Value |
|---|---|
| `OPENAI_API_KEY` | A project API key from the OpenAI platform |
| `ADMIN_PASSWORD` | A unique, strong dashboard password |
| `SESSION_SECRET` | At least 32 random bytes; generate with the command below |
| `APP_BASE_URL` | The final Replit deployment URL, without a trailing slash |
| `OPENAI_MODEL` | `gpt-5.6-terra` (the default; a good cost/quality balance) |

Generate a session secret in the Shell, then copy only the printed result into Replit Secrets:

```bash
python -c "import secrets; print(secrets.token_urlsafe(48))"
```

Optional settings:

| Secret | Default | Purpose |
|---|---:|---|
| `SCHEDULER_ENABLED` | `true` | Enables the in-process daily scan |
| `SCHEDULER_HOUR` | `7` | Local hour for the daily scan |
| `SCHEDULER_MINUTE` | `30` | Local minute for the daily scan |
| `APP_TIMEZONE` | `Europe/London` | Scheduler time zone |

Optional email-alert secrets:

| Secret | Example |
|---|---|
| `SMTP_HOST` | Your mail provider's SMTP server |
| `SMTP_PORT` | `587` for STARTTLS or `465` for SSL |
| `SMTP_USERNAME` | SMTP login |
| `SMTP_PASSWORD` | SMTP/app password |
| `SMTP_FROM` | Sender address |
| `ALERT_EMAIL` | Your destination address |

Use an app-specific SMTP password where your mail provider supports one. Never put any secret in source code or the service notes.

## 4. Run and test it

Press **Run**, open the web preview and visit `/health`. You should see:

```json
{"status":"ok"}
```

Then:

1. Sign in with `ADMIN_PASSWORD`.
2. Add one sample service with a renewal date inside the next 60 days.
3. Select **Research current deals**.
4. Wait a few minutes and refresh the service page.
5. Check that the report has working source links, labels personal quotes correctly and has not claimed to submit anything.
6. Select **Run due check** on the dashboard to test automatic selection.

The first research call can take a few minutes. A failed run is shown in the audit trail with a short error message.

## 5. Publish it on Replit

For the simplest reliable deployment, select **Reserved VM**, keep the run command from `.replit`, and use a single worker. A Reserved VM stays online so the dashboard and its daily scheduler both work.

Set `APP_BASE_URL` to the published HTTPS URL. If your Replit plan offers private deployments, use one. Otherwise the URL can be reachable publicly even though the dashboard is password protected, so use a strong password and keep all saved facts non-sensitive.

An alternative is an Autoscale web deployment plus a Replit Scheduled Deployment running:

```bash
python run_due_check.py
```

In that arrangement set `SCHEDULER_ENABLED=false` on the web deployment and schedule the script daily. Both deployments must use the same Replit Database and secrets.

Official setup references: [Replit Secrets](https://docs.replit.com/core-concepts/project-editor/app-setup/secrets), [Replit SQL Database](https://docs.replit.com/features/data-and-storage/sql-database), [deployment types](https://docs.replit.com/features/publishing/deployment-types), [OpenAI Agents SDK](https://developers.openai.com/api/docs/guides/agents), and [OpenAI production practices](https://developers.openai.com/api/docs/guides/production-best-practices).

## 6. Enter information safely

Useful information includes the provider, product name, renewal date, total cost, contract length, exit fee, excess, speed/allowance, APR, key preferences and a postcode district.

Do **not** store passwords, API keys, full bank/card details, account security answers, passport/driving-licence images, a full medical history or unnecessary identity details. Insurance and credit results remain indicative until the regulated provider or comparison service completes a personalised quote or eligibility check.

For life insurance, do not cancel existing cover until replacement cover has been accepted and started. For cards and loans, do not let preliminary research trigger a hard credit search.

## How automatic research is timed

Each service has a research window, initially 60 days. Inside that window the app researches every 14 days, then every 7 days when 30 days remain, every 3 days when 14 days remain and daily for the final 3 days. It avoids duplicate queued or running reports.

## Likely operating cost

Prices below were checked on 10 August 2026. Replit and OpenAI bill in USD, so the GBP figures use approximately **£1 = $1.35** and exclude possible VAT/card FX differences.

| Item | Official USD price | Practical GBP budget |
|---|---:|---:|
| Replit Core, annual billing | $20/month, with $25 monthly credits | about £14.80/month |
| Replit Core, monthly billing | $25/month, with $25 monthly credits | about £18.50/month |
| 0.5 vCPU / 2 GiB Reserved VM | about $15.18/month | about £11.25/month, normally absorbed by Core credits |
| Replit database for this small app | Usage-based | usually within remaining credits at household scale |
| OpenAI deal report | Usage-based | budget about £0.05–£0.35 per completed report |
| Existing SMTP mailbox | Provider-dependent | often £0 incremental |

The per-report OpenAI figure is an estimate, not a tariff: it assumes a few web searches and a moderate report on GPT-5.6 Terra. It will vary with source length and number of searches. Set an OpenAI project budget and usage alert.

**Expected total:** if you already pay for Replit Core and have unused credits, this app is likely to add roughly **£0.50–£3 per month** at ordinary household usage. If Replit Core is a new purchase, budget roughly **£16–£22 per month all-in** before VAT, depending on billing cycle and how many reports you run.

Current sources: [Replit pricing](https://replit.com/pricing), [Replit deployment billing](https://docs.replit.com/billing/deployment-pricing), [August 2026 cloud rates](https://docs.replit.com/billing/aug-cloud-billing-updates), and [OpenAI API pricing](https://developers.openai.com/api/docs/pricing).

## Build cost

Using this supplied starter, there is no software licence or developer charge; expect a few hours for your own Replit, database, secrets, email and acceptance-test setup.

If you hire someone, a reasonable planning allowance—not a quoted market price—is **£2,000–£6,000** to harden, customise and deploy this MVP. Integrations that read email attachments, extract renewal documents, automate comparison-site forms or support multiple household users can move the build into the **£6,000–£15,000+** range and create additional privacy and provider-terms work.

## Troubleshooting

- **Cannot sign in:** confirm `ADMIN_PASSWORD` is in Secrets, then restart the app.
- **Research fails immediately:** confirm `OPENAI_API_KEY`, API billing and project budget.
- **Database errors after publishing:** add Replit Database and confirm `DATABASE_URL` reaches the deployment.
- **Automatic research never runs:** use a Reserved VM, or use the separate Scheduled Deployment approach above.
- **Email does not arrive:** verify all six SMTP secrets and check the SMTP provider's app-password policy.
- **Cookie/login loop after publishing:** confirm the site is opened through its HTTPS deployment URL and restart after changing `SESSION_SECRET`.

## Run local checks

After dependencies are installed:

```bash
python -m unittest discover -s tests -v
python -m compileall app run_due_check.py
```
