# Trading agent blueprint — UK, £60 starting balance

## Bottom line

A low-frequency autonomous trading system is technically possible, but **profit is not assured and the full £60 can be lost**. With this account size, operating cost and broker rules matter more than clever AI. The sensible build sequence is: paper simulator, deterministic risk engine, broker-terms verification, supervised live pilot, and only then tightly limited autonomy.

Do not connect the renewal app to a broker. Use a separate Replit app, database, secrets, broker key and deployment. The AI may propose a trade; only ordinary code should be allowed to approve its size and submit it.

## Important broker finding

- Robinhood's US service now documents an official **Agentic Trading** account that can let an agent trade without per-order confirmation. I found no equivalent official Robinhood UK Agentic Trading documentation, so a UK implementation should not assume access. Recheck with Robinhood UK before building.
- Trading 212 exposes a beta Public API for Invest and Stocks ISA accounts, but its API Terms dated 17 October 2025 expressly prohibit using the API for “Algorithmic Trading,” which the terms define as automatic determination of order timing, price or quantity with limited/no human intervention. It is therefore **not suitable for the autonomous design described here unless Trading 212 gives prior written permission or changes its terms**.
- Interactive Brokers publishes APIs for autonomous order access and paper accounts, but authentication, market data and small-order commissions need to be tested. Its current education material includes Web API fractional-share orders, while some older TWS API documentation reports fractional-order restrictions. Confirm the exact UK account/API combination in writing before choosing it.

Relevant primary sources: [Robinhood US Agentic Trading overview](https://robinhood.com/us/en/support/articles/agentic-trading-overview/), [Trading 212 API Terms](https://www.trading212.com/legal-documentation/API-Terms_EN.pdf), [Trading 212 API key permissions](https://helpcentre.trading212.com/hc/en-us/articles/14584770928157-Trading-212-API-key), [IBKR API introduction](https://ibkrcampus.com/campus/ibkr-api-page/twsapi-doc/), and [IBKR API course](https://ibkrcampus.com/traders-academy/api/).

## The right architecture

```mermaid
flowchart TD
    A["Scheduled market scan"] --> B["Data and news collector"]
    B --> C["AI trade proposal"]
    C --> D{"Deterministic risk gate"}
    D -->|Reject| E["Audit log and alert"]
    D -->|Approve| F["Paper or broker adapter"]
    F --> G["Fill reconciliation"]
    G --> H{"Loss or system limit?"}
    H -->|Yes| I["Kill switch"]
    H -->|No| A
```

The model must never hold the broker secret, call the broker directly, edit the risk rules, increase its capital ceiling or approve its own exception. The execution service accepts only a validated order object from the risk gate.

## Example first-version policy

These are conservative engineering defaults for testing, not a recommendation to buy any security and not a claim that the strategy will profit.

| Control | Paper-test default | Live pilot default |
|---|---:|---:|
| Total capital ceiling | £60 virtual | £60 funded; deposits disabled |
| Account type | Cash only | Cash only |
| Margin, options, CFDs, shorts, leverage | Prohibited | Prohibited |
| New position size | max 20% (£12) | max 10% (£6), subject to broker minimums |
| All individual shares combined | max 50% | max 30% |
| “High risk” allocation | max 10% | 0% in version 1 |
| New orders | max 2/day | max 1/day |
| Open positions | max 5 | max 3 |
| Daily loss trigger | 2% | 2% (£1.20); freeze new orders |
| Total drawdown trigger | 10% | 10% (£6); cancel orders and disable execution |
| Trading hours | Regular session only | Regular session only |
| Order type | Limit, day-only | Limit, day-only |
| Eligible universe | Large, liquid shares/ETFs | Explicit whitelist only |

A loss limit cannot guarantee an exact maximum because prices can gap and orders can fill at unexpected levels. It is a shutdown trigger, not insurance.

## Build stages

### Stage 1 — requirements and broker gate

Write `risk_policy.yaml` first. Define the capital ceiling, eligible instruments, maximum position and sector concentration, high-risk definition, order frequency, drawdown, stale-data threshold and kill-switch process. Ask the shortlisted broker to confirm that personal algorithmic execution, fractional orders and the intended hosting/authentication method are permitted.

### Stage 2 — deterministic paper trader

Build a broker-independent simulator with:

- Recorded market data and a clear timestamp/source
- Commission, spread, FX and slippage assumptions
- A fixed strategy whose rules can be backtested
- An append-only log of every input, proposal, rejection, order and simulated fill
- Cash, positions, realised/unrealised P&L and benchmark return
- No use of future data in historical decisions

Start with a simple, explainable daily or weekly rule. Do not start with intraday prediction, options, penny stocks or a model allowed to invent a new strategy on every run.

### Stage 3 — AI research layer

The AI returns a typed proposal containing ticker, thesis, contrary evidence, confidence, data timestamps, proposed side, entry limit, maximum notional, exit condition, risk category and source URLs. Missing or stale data must produce `NO_TRADE`.

The AI's confidence never relaxes a hard rule. The risk engine recalculates every number from current cash, positions and independently fetched prices.

### Stage 4 — validation

Run at least 8–12 weeks and at least 100 decision cycles. Use walk-forward testing rather than optimising and testing on the same period. Compare return and maximum drawdown against a relevant passive benchmark and cash, after estimated costs. Require:

- Zero risk-gate bypasses
- Zero duplicate orders
- Correct recovery from API timeouts and partial fills
- A tested manual kill switch
- Reconciliation of internal records with broker/paper records
- No result presented as “profitable” without a meaningful out-of-sample period

### Stage 5 — supervised live pilot

Use a broker-supported paper environment first. Then run live in proposal-only mode, where you approve each order, for several weeks. Only enable autonomous submission after the exact strategy, account and API comply with broker terms and all controls have passed.

Keep the account at £60, disable deposits/withdrawals in the code, rotate API keys, request the minimum broker permissions, restrict source IPs if Replit provides a stable egress option, and alert yourself on every order, rejection, fill and kill-switch event.

## Costs to build

Using your own time, open-source Python and the later starter code has no developer licence cost. Professional build estimates below are planning ranges, not quotes:

| Scope | Indicative build cost |
|---|---:|
| Paper-trading prototype with fixed rules and dashboard | £4,000–£10,000 |
| Guarded live MVP with broker integration, reconciliation, alerts and kill switch | £8,000–£20,000 |
| Production hardening, independent code/security review and stronger testing | £15,000–£40,000+ |

The largest cost is engineering and validation, not the language model. A strategy that passes a backtest can still lose live money.

## Costs to run

At roughly £1 = $1.35 on 10 August 2026:

| Item | Lean, low-frequency budget |
|---|---:|
| Daily Scheduled Deployment | Usually within Replit Core credits at this scale |
| Separate always-on 0.5 vCPU Reserved VM | about £11.25/month of usage |
| OpenAI daily analysis | approximately £1–£5/month, depending on searches/tokens |
| Broker commissions / FX / exchange fees | Broker- and instrument-dependent |
| Premium real-time market data | £0–£100+/month; not economically sensible for £60 |

If the renewal agent uses one Reserved VM and the trader uses a second, their VM usage is about **$30.36/month** against Replit Core's **$25 monthly credits**, leaving roughly **$5.36 (about £4) of compute overage** before database and API usage. A daily Scheduled Deployment is likely cheaper than a second always-on VM and is the preferred design for low-frequency trading.

With a new annual Replit Core subscription, both agents can plausibly run for about **£17–£25/month before VAT** using one Reserved VM plus one scheduled trader and modest AI usage. An always-on trading scanner or frequent web/market-data calls could push this to **£30–£100+ per month**, which is plainly disproportionate to £60 of capital.

For perspective, a 10% annual return on £60 is only £6 before costs and tax. Even a technically successful system is unlikely to cover its cloud cost at that balance. Treat the £60 as a controlled learning experiment, not an income plan.

## Regulatory and decision cautions

The UK FCA warns that general AI can provide wrong or out-of-date investment information, cannot predict the future and may not provide the protections that apply to regulated advice. Keep sources visible, distinguish research from regulated advice and verify the tax treatment of the selected account. See the FCA's [Using AI for investment research](https://www.fca.org.uk/investsmart/using-ai-investment-research).

Before writing live broker code, decide:

1. Which broker confirms that this use is permitted for your UK account?
2. Cash account or Stocks and Shares ISA, if the API supports it?
3. Which instruments are explicitly allowed?
4. What exactly counts as “high risk”?
5. What benchmark and test period will determine whether the system graduates from paper trading?

No one can honestly promise that an autonomous agent will produce a profit. The build can enforce disciplined risk and reliable execution; it cannot manufacture an investment edge.
