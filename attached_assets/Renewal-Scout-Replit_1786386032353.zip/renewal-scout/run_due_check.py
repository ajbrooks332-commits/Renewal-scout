"""Run one renewal scan, useful for a Replit Scheduled Deployment."""

import asyncio

from app.agent_service import scan_due_services
from app.database import Base, engine


async def main() -> None:
    Base.metadata.create_all(bind=engine)
    run_ids = await scan_due_services()
    print(f"Completed due-service scan; processed {len(run_ids)} research run(s).")


if __name__ == "__main__":
    asyncio.run(main())

