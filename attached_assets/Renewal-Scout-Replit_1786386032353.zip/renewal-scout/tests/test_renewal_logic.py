from datetime import date
import unittest

from app.models import Service
from app.renewal_logic import calculate_next_research_date, days_until_target, needs_research


class RenewalLogicTests(unittest.TestCase):
    def service(self, **overrides):
        values = {
            "service_type": "Broadband",
            "provider": "ExampleNet",
            "renewal_date": date(2027, 3, 1),
            "notice_days": 30,
            "research_window_days": 60,
            "active": True,
            "auto_research": True,
        }
        values.update(overrides)
        return Service(**values)

    def test_days_until_target_uses_earliest_date(self):
        service = self.service(contract_end_date=date(2027, 2, 15))
        self.assertEqual(days_until_target(service, date(2027, 2, 1)), 14)

    def test_service_becomes_due_inside_research_window(self):
        service = self.service()
        self.assertTrue(needs_research(service, date(2027, 1, 15)))
        self.assertFalse(needs_research(service, date(2026, 12, 1)))

    def test_next_run_frequency_increases_near_renewal(self):
        service = self.service(renewal_date=date(2027, 3, 1))
        self.assertEqual(calculate_next_research_date(service, date(2027, 1, 1)), date(2027, 1, 15))
        self.assertEqual(calculate_next_research_date(service, date(2027, 2, 20)), date(2027, 2, 23))
        self.assertEqual(calculate_next_research_date(service, date(2027, 2, 28)), date(2027, 3, 1))


if __name__ == "__main__":
    unittest.main()
