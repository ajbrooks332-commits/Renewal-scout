from __future__ import annotations

import os
from dataclasses import dataclass


def env_bool(name: str, default: bool) -> bool:
    value = os.getenv(name)
    if value is None:
        return default
    return value.strip().lower() in {"1", "true", "yes", "on"}


def env_int(name: str, default: int) -> int:
    try:
        return int(os.getenv(name, str(default)))
    except ValueError:
        return default


@dataclass(frozen=True)
class Settings:
    app_name: str = "Renewal Scout"
    database_url: str = os.getenv("DATABASE_URL", "sqlite:///./renewals.db")
    openai_api_key: str = os.getenv("OPENAI_API_KEY", "")
    openai_model: str = os.getenv("OPENAI_MODEL", "gpt-5.6-terra")
    admin_password: str = os.getenv("ADMIN_PASSWORD", "")
    session_secret: str = os.getenv(
        "SESSION_SECRET", "development-only-change-before-publishing"
    )
    app_base_url: str = os.getenv("APP_BASE_URL", "http://localhost:8080")
    scheduler_enabled: bool = env_bool("SCHEDULER_ENABLED", True)
    scheduler_hour: int = env_int("SCHEDULER_HOUR", 7)
    scheduler_minute: int = env_int("SCHEDULER_MINUTE", 30)
    timezone: str = os.getenv("APP_TIMEZONE", "Europe/London")
    smtp_host: str = os.getenv("SMTP_HOST", "")
    smtp_port: int = env_int("SMTP_PORT", 587)
    smtp_username: str = os.getenv("SMTP_USERNAME", "")
    smtp_password: str = os.getenv("SMTP_PASSWORD", "")
    smtp_from: str = os.getenv("SMTP_FROM", "")
    alert_email: str = os.getenv("ALERT_EMAIL", "")
    is_deployed: bool = os.getenv("REPLIT_DEPLOYMENT") == "1"

    @property
    def email_enabled(self) -> bool:
        return bool(self.smtp_host and self.smtp_from and self.alert_email)

    @property
    def setup_warnings(self) -> list[str]:
        warnings: list[str] = []
        if not self.admin_password:
            warnings.append("ADMIN_PASSWORD has not been set in Replit Secrets.")
        if not self.openai_api_key:
            warnings.append("OPENAI_API_KEY has not been set; research cannot run.")
        if self.is_deployed and self.session_secret.startswith("development-only"):
            warnings.append("SESSION_SECRET must be replaced before publishing.")
        return warnings


settings = Settings()
