from __future__ import annotations

import asyncio

from apscheduler.schedulers.background import BackgroundScheduler

from .agent_service import scan_due_services
from .config import settings


scheduler = BackgroundScheduler(timezone=settings.timezone)


def _scheduled_scan() -> None:
    asyncio.run(scan_due_services())


def start_scheduler() -> None:
    if scheduler.running:
        return
    scheduler.add_job(
        _scheduled_scan,
        "cron",
        hour=settings.scheduler_hour,
        minute=settings.scheduler_minute,
        id="daily-renewal-scan",
        replace_existing=True,
        coalesce=True,
        max_instances=1,
    )
    scheduler.start()


def stop_scheduler() -> None:
    if scheduler.running:
        scheduler.shutdown(wait=False)

