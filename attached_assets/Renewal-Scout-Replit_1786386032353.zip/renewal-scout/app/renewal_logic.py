from __future__ import annotations

from datetime import date, timedelta

from .models import Service


def target_date(service: Service) -> date | None:
    dates = [d for d in (service.renewal_date, service.contract_end_date) if d]
    return min(dates) if dates else None


def days_until_target(service: Service, today: date | None = None) -> int | None:
    today = today or date.today()
    target = target_date(service)
    return (target - today).days if target else None


def needs_research(service: Service, today: date | None = None) -> bool:
    today = today or date.today()
    if not service.active or not service.auto_research:
        return False
    if service.next_research_at:
        return service.next_research_at <= today
    remaining = days_until_target(service, today)
    return remaining is not None and 0 <= remaining <= service.research_window_days


def calculate_next_research_date(
    service: Service, today: date | None = None
) -> date | None:
    today = today or date.today()
    remaining = days_until_target(service, today)
    if remaining is None or remaining < 0:
        return None
    if remaining > 30:
        interval = 14
    elif remaining > 14:
        interval = 7
    elif remaining > 3:
        interval = 3
    else:
        interval = 1
    proposed = today + timedelta(days=interval)
    target = target_date(service)
    return min(proposed, target) if target else proposed

