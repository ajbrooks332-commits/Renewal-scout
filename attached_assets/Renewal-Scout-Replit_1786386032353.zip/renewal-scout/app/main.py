from __future__ import annotations

from contextlib import asynccontextmanager
from datetime import date
from pathlib import Path
from typing import Any

from fastapi import BackgroundTasks, FastAPI, HTTPException, Request
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from sqlalchemy import select
from starlette.middleware.sessions import SessionMiddleware

from .agent_service import execute_research, queue_research, report_from_run, scan_due_services
from .config import settings
from .database import Base, SessionLocal, engine
from .models import ResearchRun, Service
from .renewal_logic import days_until_target, needs_research, target_date
from .scheduler import start_scheduler, stop_scheduler
from .security import csrf_token, is_authenticated, password_is_valid, validate_csrf


BASE_DIR = Path(__file__).resolve().parent
SERVICE_TYPES = [
    "Broadband",
    "Electricity",
    "Gas and electricity",
    "Car insurance",
    "Home insurance",
    "Life insurance",
    "Credit card",
    "Loan",
    "Mobile phone",
    "Other",
]


@asynccontextmanager
async def lifespan(_: FastAPI):
    Base.metadata.create_all(bind=engine)
    if settings.scheduler_enabled:
        start_scheduler()
    yield
    stop_scheduler()


app = FastAPI(title=settings.app_name, lifespan=lifespan)
app.add_middleware(
    SessionMiddleware,
    secret_key=settings.session_secret,
    same_site="lax",
    https_only=settings.is_deployed,
    max_age=60 * 60 * 12,
)
app.mount("/static", StaticFiles(directory=BASE_DIR / "static"), name="static")
templates = Jinja2Templates(directory=BASE_DIR / "templates")


def money(value: Any) -> str:
    if value is None:
        return "—"
    try:
        return f"£{float(value):,.2f}"
    except (TypeError, ValueError):
        return "—"


templates.env.filters["money"] = money


def render(request: Request, template: str, **context: Any) -> HTMLResponse:
    context.update(
        {
            "request": request,
            "app_name": settings.app_name,
            "csrf_token": csrf_token(request),
            "setup_warnings": settings.setup_warnings,
        }
    )
    return templates.TemplateResponse(request=request, name=template, context=context)


def require_login(request: Request) -> RedirectResponse | None:
    if not is_authenticated(request):
        return RedirectResponse("/login", status_code=303)
    return None


def optional_text(value: Any) -> str | None:
    text = str(value or "").strip()
    return text or None


def optional_float(value: Any) -> float | None:
    try:
        text = str(value or "").strip()
        return float(text) if text else None
    except ValueError:
        return None


def optional_date(value: Any) -> date | None:
    try:
        text = str(value or "").strip()
        return date.fromisoformat(text) if text else None
    except ValueError:
        return None


def bounded_int(value: Any, default: int, minimum: int, maximum: int) -> int:
    try:
        return max(minimum, min(maximum, int(value)))
    except (TypeError, ValueError):
        return default


def apply_service_form(service: Service, form: Any) -> None:
    service.service_type = str(form.get("service_type", "Other"))[:40]
    service.provider = str(form.get("provider", "")).strip()[:160]
    service.product_name = optional_text(form.get("product_name"))
    service.monthly_cost_gbp = optional_float(form.get("monthly_cost_gbp"))
    service.annual_cost_gbp = optional_float(form.get("annual_cost_gbp"))
    service.renewal_date = optional_date(form.get("renewal_date"))
    service.contract_end_date = optional_date(form.get("contract_end_date"))
    service.notice_days = bounded_int(form.get("notice_days"), 30, 0, 365)
    service.research_window_days = bounded_int(
        form.get("research_window_days"), 60, 1, 365
    )
    service.location = optional_text(form.get("location"))
    service.current_terms = optional_text(form.get("current_terms"))
    service.preferences = optional_text(form.get("preferences"))
    service.quote_facts = optional_text(form.get("quote_facts"))
    service.auto_research = form.get("auto_research") == "on"


@app.get("/health")
async def health() -> dict[str, str]:
    return {"status": "ok"}


@app.get("/login", response_class=HTMLResponse)
async def login_page(request: Request):
    if is_authenticated(request):
        return RedirectResponse("/", status_code=303)
    return render(request, "login.html", error=None)


@app.post("/login", response_class=HTMLResponse)
async def login(request: Request):
    form = await request.form()
    validate_csrf(request, form.get("csrf_token"))
    if password_is_valid(str(form.get("password", ""))):
        request.session.clear()
        request.session["authenticated"] = True
        csrf_token(request)
        return RedirectResponse("/", status_code=303)
    error = (
        "Set ADMIN_PASSWORD in Replit Secrets before signing in."
        if not settings.admin_password
        else "Incorrect password."
    )
    return render(request, "login.html", error=error)


@app.post("/logout")
async def logout(request: Request):
    form = await request.form()
    validate_csrf(request, form.get("csrf_token"))
    request.session.clear()
    return RedirectResponse("/login", status_code=303)


@app.get("/", response_class=HTMLResponse)
async def dashboard(request: Request):
    redirect = require_login(request)
    if redirect:
        return redirect
    with SessionLocal() as db:
        services = list(
            db.scalars(select(Service).where(Service.active.is_(True)).order_by(Service.renewal_date))
        )
        latest_runs = list(
            db.scalars(select(ResearchRun).order_by(ResearchRun.created_at.desc()).limit(8))
        )
        total_annual = sum(s.effective_annual_cost or 0 for s in services)
        within_90 = sum(
            1
            for s in services
            if (days := days_until_target(s)) is not None and 0 <= days <= 90
        )
        due_now = sum(1 for s in services if needs_research(s))
    return render(
        request,
        "dashboard.html",
        services=services,
        latest_runs=latest_runs,
        total_annual=total_annual,
        within_90=within_90,
        due_now=due_now,
        days_until_target=days_until_target,
        target_date=target_date,
        message=request.query_params.get("message"),
    )


@app.get("/services/new", response_class=HTMLResponse)
async def new_service(request: Request):
    redirect = require_login(request)
    if redirect:
        return redirect
    return render(
        request,
        "service_form.html",
        service=None,
        service_types=SERVICE_TYPES,
        form_title="Add a household service",
    )


@app.post("/services")
async def create_service(request: Request):
    redirect = require_login(request)
    if redirect:
        return redirect
    form = await request.form()
    validate_csrf(request, form.get("csrf_token"))
    service = Service(service_type="Other", provider="")
    apply_service_form(service, form)
    if not service.provider:
        raise HTTPException(status_code=422, detail="Provider is required.")
    with SessionLocal() as db:
        db.add(service)
        db.commit()
        db.refresh(service)
        service_id = service.id
    return RedirectResponse(f"/services/{service_id}?message=Service+added", status_code=303)


@app.get("/services/{service_id}", response_class=HTMLResponse)
async def service_detail(service_id: int, request: Request):
    redirect = require_login(request)
    if redirect:
        return redirect
    with SessionLocal() as db:
        service = db.get(Service, service_id)
        if not service:
            raise HTTPException(status_code=404, detail="Service not found.")
        runs = list(
            db.scalars(
                select(ResearchRun)
                .where(ResearchRun.service_id == service_id)
                .order_by(ResearchRun.created_at.desc())
                .limit(12)
            )
        )
        latest_complete = next((run for run in runs if run.status == "complete"), None)
        report = report_from_run(latest_complete)
    return render(
        request,
        "service_detail.html",
        service=service,
        runs=runs,
        report=report,
        target=target_date(service),
        days_remaining=days_until_target(service),
        message=request.query_params.get("message"),
    )


@app.get("/services/{service_id}/edit", response_class=HTMLResponse)
async def edit_service(service_id: int, request: Request):
    redirect = require_login(request)
    if redirect:
        return redirect
    with SessionLocal() as db:
        service = db.get(Service, service_id)
        if not service:
            raise HTTPException(status_code=404, detail="Service not found.")
    return render(
        request,
        "service_form.html",
        service=service,
        service_types=SERVICE_TYPES,
        form_title="Edit household service",
    )


@app.post("/services/{service_id}")
async def update_service(service_id: int, request: Request):
    redirect = require_login(request)
    if redirect:
        return redirect
    form = await request.form()
    validate_csrf(request, form.get("csrf_token"))
    with SessionLocal() as db:
        service = db.get(Service, service_id)
        if not service:
            raise HTTPException(status_code=404, detail="Service not found.")
        apply_service_form(service, form)
        if not service.provider:
            raise HTTPException(status_code=422, detail="Provider is required.")
        db.commit()
    return RedirectResponse(f"/services/{service_id}?message=Changes+saved", status_code=303)


@app.post("/services/{service_id}/research")
async def research_service(
    service_id: int, request: Request, background_tasks: BackgroundTasks
):
    redirect = require_login(request)
    if redirect:
        return redirect
    form = await request.form()
    validate_csrf(request, form.get("csrf_token"))
    try:
        run_id = queue_research(service_id, trigger="manual")
    except ValueError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    background_tasks.add_task(execute_research, run_id)
    return RedirectResponse(
        f"/services/{service_id}?message=Research+started.+Refresh+this+page+in+a+few+minutes.",
        status_code=303,
    )


@app.post("/services/{service_id}/archive")
async def archive_service(service_id: int, request: Request):
    redirect = require_login(request)
    if redirect:
        return redirect
    form = await request.form()
    validate_csrf(request, form.get("csrf_token"))
    with SessionLocal() as db:
        service = db.get(Service, service_id)
        if not service:
            raise HTTPException(status_code=404, detail="Service not found.")
        service.active = False
        db.commit()
    return RedirectResponse("/?message=Service+archived", status_code=303)


@app.post("/run-due-check")
async def run_due_check(request: Request, background_tasks: BackgroundTasks):
    redirect = require_login(request)
    if redirect:
        return redirect
    form = await request.form()
    validate_csrf(request, form.get("csrf_token"))
    background_tasks.add_task(scan_due_services)
    return RedirectResponse("/?message=Due-service+scan+started", status_code=303)
