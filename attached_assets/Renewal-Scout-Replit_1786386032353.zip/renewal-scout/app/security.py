from __future__ import annotations

import hmac
import secrets

from fastapi import HTTPException, Request

from .config import settings


def password_is_valid(candidate: str) -> bool:
    if not settings.admin_password:
        return False
    return hmac.compare_digest(candidate, settings.admin_password)


def csrf_token(request: Request) -> str:
    token = request.session.get("csrf_token")
    if not token:
        token = secrets.token_urlsafe(32)
        request.session["csrf_token"] = token
    return token


def validate_csrf(request: Request, submitted: str | None) -> None:
    expected = request.session.get("csrf_token", "")
    if not submitted or not expected or not hmac.compare_digest(submitted, expected):
        raise HTTPException(status_code=403, detail="Invalid form token. Refresh and retry.")


def is_authenticated(request: Request) -> bool:
    return request.session.get("authenticated") is True

