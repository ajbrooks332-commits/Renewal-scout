from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, Field


class DealOption(BaseModel):
    provider: str
    product_name: str
    price_status: Literal[
        "confirmed_public",
        "indicative",
        "personal_quote_required",
        "unavailable",
    ]
    annual_cost_gbp: float | None
    monthly_cost_gbp: float | None
    contract_length_months: int | None
    headline_terms: list[str] = Field(default_factory=list)
    important_exclusions: list[str] = Field(default_factory=list)
    source_urls: list[str] = Field(default_factory=list)


class DealReport(BaseModel):
    service_type: str
    as_of_date: str
    scope_statement: str
    current_deal_assessment: str
    options: list[DealOption] = Field(default_factory=list)
    recommended_next_step: str
    estimated_annual_saving_gbp: float | None
    missing_information: list[str] = Field(default_factory=list)
    comparison_checklist: list[str] = Field(default_factory=list)
    application_pack: list[str] = Field(default_factory=list)
    warnings: list[str] = Field(default_factory=list)
    sources: list[str] = Field(default_factory=list)

