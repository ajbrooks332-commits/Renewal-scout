from __future__ import annotations

import smtplib
from email.message import EmailMessage

from .config import settings
from .schemas import DealReport


def send_email(subject: str, body: str) -> None:
    if not settings.email_enabled:
        return

    message = EmailMessage()
    message["Subject"] = subject
    message["From"] = settings.smtp_from
    message["To"] = settings.alert_email
    message.set_content(body)

    if settings.smtp_port == 465:
        with smtplib.SMTP_SSL(settings.smtp_host, settings.smtp_port, timeout=20) as smtp:
            if settings.smtp_username:
                smtp.login(settings.smtp_username, settings.smtp_password)
            smtp.send_message(message)
        return

    with smtplib.SMTP(settings.smtp_host, settings.smtp_port, timeout=20) as smtp:
        smtp.starttls()
        if settings.smtp_username:
            smtp.login(settings.smtp_username, settings.smtp_password)
        smtp.send_message(message)


def send_research_alert(
    service_id: int, provider: str, report: DealReport
) -> None:
    saving = report.estimated_annual_saving_gbp
    saving_text = (
        f"Estimated annual saving: £{saving:,.2f}\n" if saving is not None else ""
    )
    body = (
        f"Renewal Scout completed research for {provider}.\n\n"
        f"{report.current_deal_assessment}\n\n"
        f"Recommended next step:\n{report.recommended_next_step}\n\n"
        f"{saving_text}"
        f"Review the full comparison: {settings.app_base_url}/services/{service_id}\n\n"
        "No purchase, switch, cancellation or credit application has been submitted."
    )
    send_email(f"Renewal research ready: {provider}", body)

